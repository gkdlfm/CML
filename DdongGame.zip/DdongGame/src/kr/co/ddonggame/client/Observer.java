package kr.co.ddonggame.client;

public interface Observer {
	void update(String msg);
}
